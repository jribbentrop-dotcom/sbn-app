/**
 * useMeasureSelection — Measure-level selection for the tab editor.
 *
 * Separate from useSelection (note-level copy/paste). The two are mutually
 * exclusive: activating one must clear the other (enforced in TabEditor.vue).
 *
 * Selection is stored as a Set<globalMeasureIndex> so multi-select,
 * range-select, and toggle all operate in O(1).
 */

import { ref, computed } from 'vue';

export function useMeasureSelection() {
    const selectedMeasures = ref(new Set());  // Set<globalMeasureIndex>
    const selectionAnchor  = ref(null);       // globalMeasureIndex or null

    const hasSelection     = computed(() => selectedMeasures.value.size > 0);
    const selectionCount   = computed(() => selectedMeasures.value.size);

    function isSelected(measureIndex) {
        return selectedMeasures.value.has(measureIndex);
    }

    /** Click (no modifier): select this measure only. */
    function selectSingle(measureIndex) {
        selectedMeasures.value = new Set([measureIndex]);
        selectionAnchor.value  = measureIndex;
    }

    /** Ctrl+Click: toggle this measure in/out of the selection. */
    function toggleSelect(measureIndex) {
        const next = new Set(selectedMeasures.value);
        if (next.has(measureIndex)) {
            next.delete(measureIndex);
        } else {
            next.add(measureIndex);
        }
        selectedMeasures.value = next;
        // Anchor intentionally not updated on toggle
    }

    /**
     * Shift+Click: extend selection from the anchor to toIndex (inclusive),
     * replacing the current selection.
     */
    function selectRange(fromIndex, toIndex) {
        const lo   = Math.min(fromIndex, toIndex);
        const hi   = Math.max(fromIndex, toIndex);
        const next = new Set();
        for (let i = lo; i <= hi; i++) next.add(i);
        selectedMeasures.value = next;
        // Anchor stays at the original click point
    }

    function clearSelection() {
        selectedMeasures.value = new Set();
        selectionAnchor.value  = null;
    }

    /** Sorted array of selected global measure indices. */
    function getSelectedIndices() {
        return [...selectedMeasures.value].sort((a, b) => a - b);
    }

    return {
        selectedMeasures,
        selectionAnchor,
        hasSelection,
        selectionCount,
        isSelected,
        selectSingle,
        toggleSelect,
        selectRange,
        clearSelection,
        getSelectedIndices,
    };
}
